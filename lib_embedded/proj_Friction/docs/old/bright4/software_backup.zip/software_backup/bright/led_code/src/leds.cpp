#include "leds.h"

// LightManager definition
LightManager::LightManager()
{
	light_block_list.clear();

	target_freq = WS2811_TARGET_FREQ;
	gpio_pin = 18;
	dma = 10;
	strip_type = WS2811_STRIP_GBR;
	led_count = 280;
}

LightManager::~LightManager()
{
	for(size_t i=0; i<light_block_list.size(); i++)
	{
		if(light_block_list[i] != NULL)
			delete light_block_list[i];
	}
	light_block_list.clear();
}

/////////////////////
// Data management //
/////////////////////

// Setters
void LightManager::AppendLightBlock(LightBlock* light_block)
{
	light_block_list.push_back(light_block);
}

// Getters
ws2811_t* LightManager::GetLEDString()
{
	return &ledstring;
}

/////////////////////////
// Animation functions //
/////////////////////////

ws2811_return_t LightManager::Initialize()
{
	//ledstring.freq = TARGET_FREQ;
	ledstring.freq = target_freq;
	//ledstring.dmanum = DMA;
	ledstring.dmanum = dma;
	//ledstring.channel[0].gpionum = GPIO_PIN;
	ledstring.channel[0].gpionum = gpio_pin;
	//ledstring.channel[0].count = LED_COUNT;
	ledstring.channel[0].count = led_count;
	ledstring.channel[0].invert = 0;
	ledstring.channel[0].brightness = 255;
	//ledstring.channel[0].strip_type = STRIP_TYPE;
	ledstring.channel[0].strip_type = strip_type;
	ledstring.channel[1].gpionum = 0;
	ledstring.channel[1].count = 0;
	ledstring.channel[1].invert = 0;
	ledstring.channel[1].brightness = 0;

	ws2811_return_t ret;
	if ((ret = ws2811_init(&ledstring)) != WS2811_SUCCESS)
	{
		fprintf(stderr, "ws2811_init failed: %s\n", ws2811_get_return_t_str(ret));
		return ret;
	}

	return WS2811_SUCCESS;
}

ws2811_return_t LightManager::Update()
{
	for(size_t i=0; i<light_block_list.size(); i++)
	{
		for(size_t j=0; j<light_block_list[i]->GetLEDCount(); j++)
		{
			size_t global_index = j + light_block_list[i]->GetStartIndex();
			ledstring.channel[0].leds[global_index] = light_block_list[i]->GetColor(j);
		}
	}

	return WS2811_SUCCESS;
}

ws2811_return_t LightManager::Render()
{
    ws2811_return_t ret;
	if ((ret = ws2811_render(&ledstring)) != WS2811_SUCCESS)
	{
		fprintf(stderr, "ws2811_render failed: %s\n", ws2811_get_return_t_str(ret));
		return ret;
	}

	return WS2811_SUCCESS;
}

ws2811_return_t LightManager::Clear()
{
	for(int i=0; i<ledstring.channel[0].count; i++)
		ledstring.channel[0].leds[i] = 0x00000000;

	return WS2811_SUCCESS;
}

ws2811_return_t LightManager::Shutdown()
{
	return WS2811_SUCCESS;
	//ws2811_fini(&ledstring);
}

void LightManager::TurnOffBlocks()
{
	for(size_t i=0; i<light_block_list.size(); i++)
		light_block_list[i]->TurnOff();
}

void LightManager::TurnOnBlocks()
{
	for(size_t i=0; i<light_block_list.size(); i++)
		light_block_list[i]->TurnOn();
}

void LightManager::TurnOffBlock(size_t index)
{
	if(index >= light_block_list.size())
		return;

	light_block_list[index]->TurnOff();
}

void LightManager::TurnOnBlock(size_t index)
{
	if(index >= light_block_list.size())
		return;

	light_block_list[index]->TurnOn();
}

/////////////////////////
// Debugging functions //
/////////////////////////

void LightManager::Print()
{
	for(size_t i=0; i<light_block_list.size(); i++)
		light_block_list[i]->Print();
}
