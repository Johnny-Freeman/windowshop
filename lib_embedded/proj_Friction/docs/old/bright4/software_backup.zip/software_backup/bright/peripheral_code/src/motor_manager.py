#!/usr/bin/python
import time
from Adafruit_MotorHAT import Adafruit_MotorHAT, Adafruit_DCMotor, Adafruit_StepperMotor

class MotorManager:
	def __init__(self):
		self.motor_hat = Adafruit_MotorHAT()
		self.stepper_motor = self.motor_hat.getStepper(200, 1)

		self.direction = None
		self.start_time = 0
		self.stop_time = 0

	def Initialize(self):
		self.stepper_motor.setSpeed(30)

	def Update(self):
		cur_time = time.time()
		while cur_time > self.start_time and cur_time < self.stop_time:
			self.stepper_motor.step(20, self.direction,  Adafruit_MotorHAT.DOUBLE)
			cur_time = time.time()
			#print 'Running motor! %.2f %.2f %.2f' % (cur_time, self.start_time, self.stop_time)

		#time.sleep(1)
		self.motor_hat.getMotor(1).run(Adafruit_MotorHAT.RELEASE)
		self.motor_hat.getMotor(2).run(Adafruit_MotorHAT.RELEASE)
		self.motor_hat.getMotor(3).run(Adafruit_MotorHAT.RELEASE)
		self.motor_hat.getMotor(4).run(Adafruit_MotorHAT.RELEASE)

	def RunMotor(self, direction, duration):
		self.direction = direction
		self.start_time = time.time()
		self.stop_time = self.start_time + duration

	def Shutdown(self):
		#print 'Motor Manager Shutting Down'
		self.motor_hat.getMotor(1).run(Adafruit_MotorHAT.RELEASE)
		self.motor_hat.getMotor(2).run(Adafruit_MotorHAT.RELEASE)
		self.motor_hat.getMotor(3).run(Adafruit_MotorHAT.RELEASE)
		self.motor_hat.getMotor(4).run(Adafruit_MotorHAT.RELEASE)
