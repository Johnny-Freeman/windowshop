#!/usr/bin/python
import os
from peripheral_manager import PeripheralManager

lcd_peripheral_manager = PeripheralManager(PeripheralManager.LCD_PERIPHERAL)
lcd_peripheral_manager.Initialize()

motor_peripheral_manager = PeripheralManager(PeripheralManager.MOTOR_PERIPHERAL)
motor_peripheral_manager.Initialize()

child_pid = os.fork()

if child_pid == 0:
	try:
		while 1:
			lcd_peripheral_manager.Update()

	except Exception as e:
		print(e)
		lcd_peripheral_manager.Shutdown()

else:
	try:
		while 1:
			motor_peripheral_manager.Update()

	except Exception as e:
		print(e)
		motor_peripheral_manager.Shutdown()
	
