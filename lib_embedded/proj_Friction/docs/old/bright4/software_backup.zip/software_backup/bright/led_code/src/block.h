#include <stdlib.h>
#include <stdio.h>

#include <vector>
using namespace std;

#include "ws2811.h"

#ifndef BLOCK_H
#define BLOCK_H

// LightBlock definition
class LightBlock
{
public:
	LightBlock();
	LightBlock(size_t start_index, size_t stop_index);
	~LightBlock();

	/////////////////////
	// Data management //
	/////////////////////

	// Setters
	void SetColor(size_t local_index, uint32_t color);

	// Getters
	size_t GetLEDCount();
	size_t GetStartIndex();
	size_t GetStopIndex();

	uint32_t GetColor(size_t local_index);

	/////////////////////////
	// Animation functions //
	/////////////////////////

	void SetColorAll(uint32_t color);

	void TurnOff();
	void TurnOn();

	/////////////////////////
	// Debugging functions //
	/////////////////////////

	void Print();

private:
	size_t start_index;
	size_t stop_index;

	size_t led_count;
	uint32_t* color_list;

	uint8_t is_on;
};
typedef vector<LightBlock*> LightBlockList;


#endif
