#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>

#include <math.h>

#include <vector>
#include <string>
using namespace std;

#include "leds.h"
#include "flow.h"
#include "rpi_gpio.h"

#ifndef LED_THERMOSTAT_H
#define LED_THERMOSTAT_H

class ThermostatManager : public LightManager
{
public:
	ThermostatManager();
	~ThermostatManager();

	/////////////////////
	// Data management //
	/////////////////////

	/////////////////////////
	// Animation functions //
	/////////////////////////

	ws2811_return_t Initialize();
	ws2811_return_t Update();
	ws2811_return_t Render();
	ws2811_return_t Clear();
	ws2811_return_t Shutdown();

	void TurnOffMainBody();
	void TurnOnMainBody();

	void TurnOffBypass();
	void TurnOnBypass();

	void TurnOffRadiator();
	void TurnOnRadiator();

	void StepThroughTemperature();
	void StepThroughBlocks();

	/////////////////////////
	// Debugging functions //
	/////////////////////////

	void Print();

	// Switch states
	enum
	{
		SWITCH_STATE_AUTO = 0,
		SWITCH_STATE_CLOSED = 1,
		SWITCH_STATE_TR = 2,
		SWITCH_STATE_OPEN = 3
	};

private:
	////////////////////////////
	// Internal use functions //
	////////////////////////////

	void UpdateLCDText();

	string GetSwitchStateString();
	void UpdateSwitchState();

	void SetLightColorFromTemperature();

	uint32_t ComputeColorFromTemperature();
	uint32_t ColorInterpolation(uint32_t color_a, uint32_t color_b, double alpha);

	///////////////////////
	// Internal use data //
	///////////////////////

	int switch_state;

	vector<double> color_transition_temperature_list;
	vector<uint32_t> color_transition_value_list;

	double lcd_temperature;
	double temperature;

	LightFlowList light_flow_list;
};

#endif
