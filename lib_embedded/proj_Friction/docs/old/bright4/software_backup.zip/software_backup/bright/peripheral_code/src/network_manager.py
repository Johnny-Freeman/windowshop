#!/usr/bin/python
import time, socket, select

class NetworkManager:
	def __init__(self, port):
		self.sock = None
		self.port = port

		self.message_list = []

	def Initialize(self):
		self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.sock.bind(('localhost', self.port))
		self.sock.listen(1)
		self.sock.setblocking(0)

	def Update(self):
		ready_to_read, ready_to_write, in_err = select.select([self.sock], [], [], 0.1)

		if len(ready_to_read)>0 and ready_to_read[0] == self.sock:
			(client, address) = self.sock.accept()

			ready_to_read, ready_to_write, in_err = select.select([client], [], [], 1)
			if len(ready_to_read)>0 and ready_to_read[0] == client:
				message = client.recv(1000)
				while message[-1] == '\r' or message[-1] == '\n':
					message = message[:-1]

				self.message_list.append(message)

			client.close()

	def PopMessage(self):
		if len(self.message_list) == 0:
			return ''

		message = self.message_list[0]
		self.message_list = self.message_list[1:]

		return message

	def Shutdown(self):
		print 'Network Manager Shutting Down'
		self.sock.close()
