#include "signals.h"

void setup_handlers(void (*handler)(int))
{
    struct sigaction sa;
    sa.sa_handler = handler;
 
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
}
