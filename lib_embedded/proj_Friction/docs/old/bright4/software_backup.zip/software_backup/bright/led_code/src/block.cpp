#include "block.h"

// LightBlock definition
LightBlock::LightBlock()
{
	start_index = 0;
	stop_index = 1;
	led_count = 0;
	color_list = NULL;

	is_on = 1;
}

LightBlock::LightBlock(size_t start_index, size_t stop_index)
{
	this->start_index = start_index;
	this->stop_index = stop_index;

	led_count = stop_index - start_index;
	if(led_count > 0)
	{
		color_list = new uint32_t[led_count];
		for(size_t i=0; i<led_count; i++)
			color_list[i] = 0;
	}
	else
		color_list = NULL;

	is_on = 1;
}

LightBlock::~LightBlock()
{
	if(color_list != NULL)
	{
		delete color_list;
		color_list = NULL;
	}
}

/////////////////////
// Data management //
/////////////////////

// Setters
void LightBlock::SetColor(size_t local_index, uint32_t color)
{
	if(local_index >= led_count)
		return;

	color_list[local_index] = color;
}

// Getters
size_t LightBlock::GetLEDCount()
{
	return led_count;
}

size_t LightBlock::GetStartIndex()
{
	return start_index;
}

size_t LightBlock::GetStopIndex()
{
	return stop_index;
}

uint32_t LightBlock::GetColor(size_t local_index)
{
	if(local_index >= led_count)
		return 0x00000000;

	uint32_t color = 0x00000000;
	if(is_on)
		color = color_list[local_index];

	return color;
}

/////////////////////////
// Animation functions //
/////////////////////////

void LightBlock::SetColorAll(uint32_t color)
{
	for(size_t i=0; i<led_count; i++)
		color_list[i] = color;
}

void LightBlock::TurnOff()
{
	is_on = 0;
}

void LightBlock::TurnOn()
{
	is_on = 1;
}

/////////////////////////
// Debugging functions //
/////////////////////////

void LightBlock::Print()
{
	printf("LightBlock\n");
	printf("start_index = %lu\n", start_index);
	printf("stop_index = %lu\n", stop_index);

	for(size_t i=0; i<led_count; i++)
		printf("color_list[%lu] = %08x\n", i, color_list[i]);

	printf("\n");
}
