#!/usr/bin/python
import time

from lcd_manager import LCD_Manager
from network_manager import NetworkManager
from motor_manager import MotorManager

from Adafruit_MotorHAT import Adafruit_MotorHAT, Adafruit_DCMotor, Adafruit_StepperMotor

class PeripheralManager:
	def __init__(self, peripheral_type):
		self.peripheral_type = peripheral_type
		self.lcd_manager = None
		self.motor_manager = None
		self.network_manager = None
		
		if self.peripheral_type == PeripheralManager.LCD_PERIPHERAL:
			self.lcd_manager = LCD_Manager()
			self.network_manager = NetworkManager(12345)

		elif self.peripheral_type == PeripheralManager.MOTOR_PERIPHERAL:
			self.motor_manager = MotorManager()
			self.network_manager = NetworkManager(12346)

	def Initialize(self):
		if self.peripheral_type == PeripheralManager.LCD_PERIPHERAL:
			self.lcd_manager.Initialize()

		elif self.peripheral_type == PeripheralManager.MOTOR_PERIPHERAL:
			self.motor_manager.Initialize()

		self.network_manager.Initialize()

	def Update(self):
		self.network_manager.Update()
		message = self.network_manager.PopMessage()
		while message != '':
			self.ParseMessage(message)
			message = self.network_manager.PopMessage()

		if self.peripheral_type == PeripheralManager.LCD_PERIPHERAL:
			self.lcd_manager.Update()

		elif self.peripheral_type == PeripheralManager.MOTOR_PERIPHERAL:
			self.motor_manager.Update()

	def ParseMessage(self, message):
		if self.peripheral_type == PeripheralManager.LCD_PERIPHERAL and message[0:3] == 'LCD':
			self.lcd_manager.SetMessage(message[4:])

		elif self.peripheral_type == PeripheralManager.MOTOR_PERIPHERAL and message[0:5] == 'MOTOR':
			#print 'MOTOR'
			direction_str = message.split(' ')[1]
			duration = float(message.split(' ')[2])

			direction = None
			if direction_str == 'FORWARD':
				#print 'FORWARD'
				direction = Adafruit_MotorHAT.FORWARD

			elif direction_str == 'BACKWARD':
				#print 'BACKWARD'
				direction = Adafruit_MotorHAT.BACKWARD

			if direction != None and duration > 0.00 and duration < 60.0:
				self.motor_manager.RunMotor(direction, duration)

	def Shutdown(self):
		print 'Peripheral Manager Shutting Down'
		if self.peripheral_type == PeripheralManager.LCD_PERIPHERAL:
			self.lcd_manager.Shutdown()

		elif self.peripheral_type == PeripheralManager.MOTOR_PERIPHERAL:
			self.motor_manager.Shutdown()
		
		self.network_manager.Shutdown()

	# Enumerations
	LCD_PERIPHERAL = 1
	MOTOR_PERIPHERAL = 2
