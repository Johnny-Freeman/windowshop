#include <stdlib.h>
#include <stdio.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include <vector>
using namespace std;

#include "ws2811.h"
#include "block.h"

#ifndef FLOW_H
#define FLOW_H

class LightFlow
{
public:
	LightFlow();
	~LightFlow();

	/////////////////////
	// Data management //
	/////////////////////

	// Setters
	void AppendLightBlock(LightBlock* light_block);

	void SetDirection(int direction);

	/////////////////////////
	// Animation functions //
	/////////////////////////

	void Update();

	/////////////////////////
	// Debugging functions //
	/////////////////////////

	void Print();

	// Direction types
	enum
	{
		DIRECTION_FORWARD = 0,
		DIRECTION_BACKWARD = 1
	};

private:
	///////////////////////
	// Internal use data //
	///////////////////////

	// Flow state
	double cur_offset;

	// Animation settings
	int direction;
	double speed;
	int width;
	int stagger;

	LightBlockList light_block_list;
};
typedef vector<LightFlow*> LightFlowList;

#endif
