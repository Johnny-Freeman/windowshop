#include "thermostat.h"

ThermostatManager::ThermostatManager()
{
	color_transition_temperature_list.clear();
	color_transition_value_list.clear();

	switch_state = ThermostatManager::SWITCH_STATE_AUTO;
	temperature = 50.00;
	lcd_temperature = 50.0;
}

ThermostatManager::~ThermostatManager()
{
	// Do nothing
}

/////////////////////
// Data management //
/////////////////////

/////////////////////////
// Animation functions //
/////////////////////////

ws2811_return_t ThermostatManager::Initialize()
{
	ws2811_return_t ret;
	if((ret = LightManager::Initialize()) != WS2811_SUCCESS)
		return ret;

	LightBlock* light_block_a = new LightBlock(56, 140);
	LightBlock* light_block_b = new LightBlock(0, 56);
	LightBlock* light_block_c = new LightBlock(157, 162);
	LightBlock* light_block_d = new LightBlock(271, 280);
	LightBlock* light_block_e = new LightBlock(162, 174);
	LightBlock* light_block_f = new LightBlock(177, 229);
	LightBlock* light_block_g = new LightBlock(140, 146);
	LightBlock* light_block_h = new LightBlock(146, 157);
	LightBlock* light_block_i = new LightBlock(229, 246);
	LightBlock* light_block_j = new LightBlock(174, 177);
	LightBlock* light_block_k = new LightBlock(246, 261);
	LightBlock* light_block_l = new LightBlock(261, 271);

	light_block_a->SetColorAll(0x000000FF);
	light_block_b->SetColorAll(0x0000FF00);
	light_block_c->SetColorAll(0x00FF0000);
	light_block_d->SetColorAll(0x000000FF);
	light_block_e->SetColorAll(0x000000FF);
	light_block_f->SetColorAll(0x000000FF);
	light_block_g->SetColorAll(0x0000FF00);
	light_block_h->SetColorAll(0x000000FF);
	light_block_i->SetColorAll(0x00FF0000);
	light_block_j->SetColorAll(0x0000FF00);
	light_block_k->SetColorAll(0x000000FF);
	light_block_l->SetColorAll(0x0000FF00);

	AppendLightBlock(light_block_a);
	AppendLightBlock(light_block_b);
	AppendLightBlock(light_block_c);
	AppendLightBlock(light_block_d);
	AppendLightBlock(light_block_e);
	AppendLightBlock(light_block_f);
	AppendLightBlock(light_block_g);
	AppendLightBlock(light_block_h);
	AppendLightBlock(light_block_i);
	AppendLightBlock(light_block_j);
	AppendLightBlock(light_block_k);
	AppendLightBlock(light_block_l);

	color_transition_temperature_list = vector<double>(8, 0.00);
	color_transition_temperature_list[0] = 50.00;
	color_transition_temperature_list[1] = 90.00;
	color_transition_temperature_list[2] = 110.00;
	color_transition_temperature_list[3] = 140.00;
	color_transition_temperature_list[4] = 175.00;
	color_transition_temperature_list[5] = 205.00;
	color_transition_temperature_list[6] = 215.00;
	color_transition_temperature_list[7] = 230.00;

	color_transition_value_list = vector<uint32_t>(8, 0x00000000);
	color_transition_value_list[0] = 0x00000000; // Black
	color_transition_value_list[1] = 0x0082004B; // Indigo
	color_transition_value_list[2] = 0x00D30094; // Violet
	color_transition_value_list[3] = 0x00FF0000; // Blue
	color_transition_value_list[4] = 0x0000FF00; // Green
	color_transition_value_list[5] = 0x0000FFFF; // Yellow
	color_transition_value_list[6] = 0x0000A5FF; // Orange
	color_transition_value_list[7] = 0x000000FF; // Red

	gpio_enable(14);
	gpio_enable(15);
	gpio_enable(23);
	gpio_enable(24);

	LightFlow* light_flow_0 = new LightFlow;
	light_flow_0->AppendLightBlock(light_block_list[7]);
	//light_flow_0->AppendLightBlock(light_block_list[2]);
	light_flow_0->AppendLightBlock(light_block_list[0]);
	light_flow_0->AppendLightBlock(light_block_list[6]);
	light_flow_0->AppendLightBlock(light_block_list[1]);
	light_flow_list.push_back(light_flow_0);

	LightFlow* light_flow_1 = new LightFlow;
	light_flow_1->AppendLightBlock(light_block_list[9]);
	light_flow_1->AppendLightBlock(light_block_list[5]);
	light_flow_1->AppendLightBlock(light_block_list[8]);
	light_flow_1->AppendLightBlock(light_block_list[10]);
	light_flow_1->AppendLightBlock(light_block_list[11]);
	light_flow_list.push_back(light_flow_1);

	LightFlow* light_flow_2 = new LightFlow;
	light_flow_2->AppendLightBlock(light_block_list[4]);
	light_flow_list.push_back(light_flow_2);

	LightFlow* light_flow_3 = new LightFlow;
	light_flow_3->SetDirection(LightFlow::DIRECTION_BACKWARD);
	light_flow_3->AppendLightBlock(light_block_list[2]);
	light_flow_list.push_back(light_flow_3);

	//system("echo \"MOTOR FORWARD 11.0\" | nc localhost 12346");
	//usleep(15e6);
	//system("echo \"MOTOR BACKWARD 10.0\" | nc localhost 12346");
	//usleep(15e6);

	return WS2811_SUCCESS;
}

ws2811_return_t ThermostatManager::Update()
{
	if(switch_state == ThermostatManager::SWITCH_STATE_AUTO)
	{
		SetLightColorFromTemperature();
		if(temperature < 190.0)
		{
			temperature += 1.0;

			TurnOnMainBody();
			TurnOnBypass();
			TurnOffRadiator();
		}
		else if(temperature >= 190.0 && temperature < 215.5)
		{
			temperature += 0.10;

			TurnOnMainBody();
			TurnOnBypass();
			TurnOnRadiator();
		}
		else
		{
			temperature += 0.05;

			TurnOnMainBody();
			TurnOffBypass();
			TurnOnRadiator();
		}
		//light_block_list[2]->TurnOff();

		if(fabs(temperature - 190.0) < 1e-6)
			system("echo \"MOTOR FORWARD 5.375\" | nc localhost 12346");

		if(fabs(temperature - 210.0) < 1e-6)
			system("echo \"MOTOR FORWARD 5.375\" | nc localhost 12346");

		if(temperature > 225.0)
		{
			temperature = 50.0;
			SetLightColorFromTemperature();
			system("echo \"MOTOR BACKWARD 10.0\" | nc localhost 12346");
			Clear();
			Render();
			usleep(15e6);
		}
	}
	else
	{
		for(size_t i=0; i<light_block_list.size(); i++)
		{
			light_block_list[i]->TurnOn();
			light_block_list[i]->SetColorAll(0xFF);
		}
	}
	for(size_t i=0; i<light_flow_list.size(); i++)
		light_flow_list[i]->Update();

	UpdateSwitchState();
	UpdateLCDText();

	return LightManager::Update();
}

ws2811_return_t ThermostatManager::Render()
{
	return LightManager::Render();
}

ws2811_return_t ThermostatManager::Clear()
{
	return LightManager::Clear();
}

ws2811_return_t ThermostatManager::Shutdown()
{
	gpio_unenable(14);
	gpio_unenable(15);
	gpio_unenable(23);
	gpio_unenable(24);

	return LightManager::Shutdown();
}

void ThermostatManager::TurnOffMainBody()
{
	light_block_list[0]->TurnOff();
	light_block_list[1]->TurnOff();
	light_block_list[2]->TurnOff();
	light_block_list[4]->TurnOff();
	light_block_list[6]->TurnOff();
	light_block_list[7]->TurnOff();
	light_block_list[8]->TurnOff();
	light_block_list[11]->TurnOff();
}

void ThermostatManager::TurnOnMainBody()
{
	light_block_list[0]->TurnOn();
	light_block_list[1]->TurnOn();
	light_block_list[2]->TurnOn();
	light_block_list[4]->TurnOn();
	light_block_list[6]->TurnOn();
	light_block_list[7]->TurnOn();
	light_block_list[8]->TurnOn();
	light_block_list[11]->TurnOn();
}

void ThermostatManager::TurnOffBypass()
{
	light_block_list[10]->TurnOff();
}

void ThermostatManager::TurnOnBypass()
{
	light_block_list[10]->TurnOn();
}

void ThermostatManager::TurnOffRadiator()
{
	light_block_list[5]->TurnOff();
	light_block_list[9]->TurnOff();
}

void ThermostatManager::TurnOnRadiator()
{
	light_block_list[5]->TurnOn();
	light_block_list[9]->TurnOn();
}

void ThermostatManager::StepThroughTemperature()
{
	for(temperature = -100.00; temperature <= 800.0; temperature += 2.0)
	{
		SetLightColorFromTemperature();
		if(temperature < 400.0)
		{
			TurnOnMainBody();
			TurnOnBypass();
			TurnOffRadiator();
		}
		else if(temperature >= 400.0 && temperature < 700.0)
		{
			TurnOnMainBody();
			TurnOnBypass();
			TurnOnRadiator();
		}
		else
		{
			TurnOnMainBody();
			TurnOffBypass();
			TurnOnRadiator();
		}
		
		Update();
		Render();

		//printf("temperature = %.2lf. Hit enter to continue...\n", temperature);
		usleep(2e5);
		//fgetc(stdin);
	}
}

void ThermostatManager::StepThroughBlocks()
{
	for(size_t i=0; i<light_block_list.size(); i++)
	{
		TurnOffBlocks();
		TurnOnBlock(i);
		Update();
		Render();

		//printf("Displaying block %lu. Hit enter to continue...\n", i);
		fgetc(stdin);
	}
}

/////////////////////////
// Debugging functions //
/////////////////////////

void ThermostatManager::Print()
{
	LightManager::Print();
}

////////////////////////////
// Internal use functions //
////////////////////////////

void ThermostatManager::UpdateLCDText()
{
	char command[1000];
	FILE* handle = fopen("/home/pi/Desktop/bright/temp.txt", "w");
	if(handle == NULL)
		return;
	fprintf(handle, "LCD %s\n%.0fF", GetSwitchStateString().c_str(), temperature);
	fclose(handle);

	sprintf(command, "cat /home/pi/Desktop/bright/temp.txt | nc localhost 12345");

	//printf("%s\n", command);
	system(command);
	
	lcd_temperature = temperature;
}

string ThermostatManager::GetSwitchStateString()
{
	if(switch_state == ThermostatManager::SWITCH_STATE_AUTO)
		return "AUTO";

	else if(switch_state == ThermostatManager::SWITCH_STATE_CLOSED)
		return "CLOSED";

	else if(switch_state == ThermostatManager::SWITCH_STATE_TR)
		return "TRANSIENT";

	else if(switch_state == ThermostatManager::SWITCH_STATE_OPEN)
		return "OPEN";

	return "UNDEF";
}

void ThermostatManager::UpdateSwitchState()
{
	//printf("ASDF\n");
	char command[1000];

	if(gpio_read(14) == 1)
	{
		switch_state = ThermostatManager::SWITCH_STATE_AUTO;
		sprintf(command, "echo \"LCD AUTO\" | nc localhost 12345");
	}

	else if(gpio_read(15) == 1)
	{
		switch_state = ThermostatManager::SWITCH_STATE_CLOSED;
		sprintf(command, "echo \"LCD CLOSED\" | nc localhost 12345");
	}

	else if(gpio_read(23) == 1)
	{
		switch_state = ThermostatManager::SWITCH_STATE_TR;
		sprintf(command, "echo \"LCD TR\" | nc localhost 12345");
	}

	else if(gpio_read(24) == 1)
	{
		switch_state = ThermostatManager::SWITCH_STATE_OPEN;
		sprintf(command, "echo \"LCD OPEN\" | nc localhost 12345");
	}

	//printf("command = %s\n", command);
	system(command);
}

void ThermostatManager::SetLightColorFromTemperature()
{
	uint32_t color = ComputeColorFromTemperature();
	//printf("color = %08x\n", color);
	for(size_t i=0; i<light_block_list.size(); i++)
		light_block_list[i]->SetColorAll(color);

	char command[1000];
	sprintf(command, "echo \"LCD Temperature:\n%.0fF\" | nc localhost 12345", temperature);
	//printf("command = %s\n", command);
	//system(command);
}

uint32_t ThermostatManager::ComputeColorFromTemperature()
{
	size_t index=0;
	double alpha = 0.00;
	uint32_t color_a = 0x00000000;
	uint32_t color_b = 0x00000000;
	if(temperature < color_transition_temperature_list[0])
	{
		return color_transition_value_list[0];
	}

	else if(temperature >= color_transition_temperature_list[color_transition_temperature_list.size()-1])
	{
		return color_transition_value_list[color_transition_value_list.size()-1];
	}

	else
	{
		for(size_t index=0; index+1<color_transition_temperature_list.size(); index++)
		{
			if(temperature >= color_transition_temperature_list[index] && temperature < color_transition_temperature_list[index+1])
			{
				color_a = color_transition_value_list[index];
				color_b = color_transition_value_list[index+1];
				alpha = (temperature - color_transition_temperature_list[index]) / (color_transition_temperature_list[index+1] - color_transition_temperature_list[index]);
				break;
			}
		}
	}
	//printf("%lu %08x %08x %.2lf %08x\n", index, color_a, color_b, alpha, ColorInterpolation(color_a, color_b, alpha));

	return ColorInterpolation(color_a, color_b, alpha);
}

uint32_t ThermostatManager::ColorInterpolation(uint32_t color_a, uint32_t color_b, double alpha)
{
	double red_a = double(color_a & 0xFF);
	double red_b = double(color_b & 0xFF);
	uint32_t red = uint32_t(floor((1.0-alpha)*red_a + alpha*red_b));

	double green_a = double((color_a>>8) & 0xFF);
	double green_b = double((color_b>>8) & 0xFF);
	uint32_t green = uint32_t(floor((1.0-alpha)*green_a + alpha*green_b));

	double blue_a = double((color_a>>16) & 0xFF);
	double blue_b = double((color_b>>16) & 0xFF);
	uint32_t blue = uint32_t(floor((1.0-alpha)*blue_a + alpha*blue_b));

	double white_a = double((color_a>>24) & 0xFF);
	double white_b = double((color_b>>24) & 0xFF);
	uint32_t white = uint32_t(floor((1.0-alpha)*white_a + alpha*white_b));

	return (white<<24) + (blue<<16) + (green<<8) + red;
}
