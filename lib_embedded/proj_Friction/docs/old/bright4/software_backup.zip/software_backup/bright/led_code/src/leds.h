#include <stdlib.h>
#include <stdio.h>

#include <vector>
using namespace std;

#include "ws2811.h"
#include "block.h"

#ifndef LEDS_H
#define LEDS_H

/*// defaults for cmdline options
#define TARGET_FREQ             WS2811_TARGET_FREQ
#define GPIO_PIN                18
#define DMA                     10
//#define STRIP_TYPE            WS2811_STRIP_RGB		// WS2812/SK6812RGB integrated chip+leds
#define STRIP_TYPE              WS2811_STRIP_GBR		// WS2812/SK6812RGB integrated chip+leds
//#define STRIP_TYPE            SK6812_STRIP_RGBW		// SK6812RGBW (NOT SK6812RGB)

#define WIDTH                   280
#define HEIGHT                  1
#define LED_COUNT               (WIDTH * HEIGHT)*/

//static ws2811_t ledstring;

// LightManager definition
class LightManager
{
public:
	LightManager();
	~LightManager();

	/////////////////////
	// Data management //
	/////////////////////

	// Setters
	void AppendLightBlock(LightBlock* light_block);

	// Getters
	ws2811_t* GetLEDString();

	/////////////////////////
	// Animation functions //
	/////////////////////////

	virtual ws2811_return_t Initialize();
	virtual ws2811_return_t Update();
	virtual ws2811_return_t Render();
	virtual ws2811_return_t Clear();
	virtual ws2811_return_t Shutdown();

	void TurnOffBlocks();
	void TurnOnBlocks();

	void TurnOffBlock(size_t index);
	void TurnOnBlock(size_t index);

	/////////////////////////
	// Debugging functions //
	/////////////////////////

	virtual void Print();

protected:
	///////////////////////
	// Internal use data //
	///////////////////////

	ws2811_t ledstring;
	LightBlockList light_block_list;

	uint32_t target_freq;
	uint32_t gpio_pin;
	uint32_t dma;
	uint32_t strip_type;
	uint32_t led_count;
};

#endif
