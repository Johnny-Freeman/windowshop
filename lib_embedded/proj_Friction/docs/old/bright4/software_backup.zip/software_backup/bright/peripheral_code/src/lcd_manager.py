#!/usr/bin/python
import Adafruit_CharLCD as LCD

class LCD_Manager:
	def __init__(self):
		self.lcd_rs        = 16
		self.lcd_en        = 20
		self.lcd_d4        = 19
		self.lcd_d5        = 26
		self.lcd_d6        = 13
		self.lcd_d7        = 6
		self.lcd_backlight = 5
		self.lcd_columns = 16
		self.lcd_rows    = 2

		self.lcd = None
		self.message_changed = False
		self.message = ''

	def Initialize(self):
		self.lcd = LCD.Adafruit_CharLCD(self.lcd_rs, self.lcd_en, self.lcd_d4, self.lcd_d5,
											self.lcd_d6, self.lcd_d7, self.lcd_columns, self.lcd_rows, self.lcd_backlight)

		self.lcd.clear()
		self.lcd.message(self.message)

	def Update(self):
		if self.message_changed:
			self.lcd.clear()
			self.lcd.message(self.message)
			self.message_changed = False

	def SetMessage(self, message):
		if message != self.message:
			self.message_changed = True

		self.message = message

	def Shutdown(self):
		print 'LCD Manager Shutting Down'
		self.lcd.clear()

