#include "flow.h"

LightFlow::LightFlow()
{
	// Flow state
	cur_offset = 0.0;

	// Animation settings
	direction = LightFlow::DIRECTION_FORWARD;
	speed = 1.0;
	stagger = 5;
	width = 2;

	light_block_list.clear();
}

LightFlow::~LightFlow()
{
	// Do nothing
}

/////////////////////
// Data management //
/////////////////////

// Setters
void LightFlow::AppendLightBlock(LightBlock* light_block)
{
	light_block_list.push_back(light_block);
}

void LightFlow::SetDirection(int direction)
{
	this->direction = direction;
}

/////////////////////////
// Animation functions //
/////////////////////////

void LightFlow::Update()
{
	if(direction == LightFlow::DIRECTION_FORWARD)
	{
		cur_offset += speed;
		if(cur_offset >= double(stagger))
			cur_offset = 0.00;
	}


	else if(direction == LightFlow::DIRECTION_BACKWARD)
	{
		cur_offset -= speed;
		if(cur_offset < 0.00)
			cur_offset = stagger;
	}



	int cur_offset_i = (int) floor(cur_offset);

	size_t count=0;
	for(size_t i=0; i<light_block_list.size(); i++)
	{
		LightBlock* light_block = light_block_list[i];
		for(size_t j=0; j<light_block->GetLEDCount(); j++)
		{
			for(int k=0; k<width; k++)
			{
				if(((count+k) % stagger) == cur_offset)
					light_block->SetColor(j, 0x00000000);
			}

			count++;
		}
	}
}

/////////////////////////
// Debugging functions //
/////////////////////////

void LightFlow::Print()
{
	// Do nothing
}
