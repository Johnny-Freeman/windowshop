#!/bin/sh

raspi-gpio set 5 pu
raspi-gpio set 6 pu
raspi-gpio set 13 pu
raspi-gpio set 19 pu
