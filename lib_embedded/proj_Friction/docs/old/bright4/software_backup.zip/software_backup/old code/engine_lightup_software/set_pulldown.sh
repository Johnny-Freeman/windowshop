#!/bin/sh

raspi-gpio set 5 pd
raspi-gpio set 6 pd
raspi-gpio set 13 pd
raspi-gpio set 19 pd
