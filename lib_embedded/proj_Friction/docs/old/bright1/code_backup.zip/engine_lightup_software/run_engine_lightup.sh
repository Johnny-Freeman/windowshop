#!/bin/sh

sh /home/pi/Desktop/engine_lightup_software/set_pulldown.sh
sudo /home/pi/Desktop/engine_lightup_software/test -c &
